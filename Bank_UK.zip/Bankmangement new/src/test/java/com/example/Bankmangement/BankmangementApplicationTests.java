package com.example.Bankmangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankmangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
