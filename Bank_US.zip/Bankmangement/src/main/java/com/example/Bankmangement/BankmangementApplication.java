package com.example.Bankmangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankmangementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankmangementApplication.class, args);
	}

}
